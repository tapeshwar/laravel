<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    
    public function user_login(Request $request){
        $username = $request->post('username');
        $password = $request->post('password');

        $user = DB::table('users')->where('username', $username)->first();
        if(!empty($user)){
            $saved_password = $user->password;

            if(password_verify($password,$saved_password)){
                session(['id' => $user->id,'username' => $user->username,'email' => $user->email,'mobile'=>$user->mobile]);
                $return['url'] = 'home/index';
                $return['status'] = 'success';
                $return['msg'] = 'Login Successfully...';
                return $return;
            }else{
                $return['status'] = 'error';
			    $return['msg'] = 'Incorrect password';
                return $return;
            }
        }else{
            $return['status'] = 'error';
			$return['msg'] = 'Invalid username';
            return $return;
        }
        //return $request->all();
    }

    
}
