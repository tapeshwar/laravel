<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    
    public function index(){
        //print_r($_SESSION);
        //echo 'index page';
        $ret_data['heading'] = 'Home';
        return view('template/template_dashboard',$ret_data);
    }
}
